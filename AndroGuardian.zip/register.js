function redirectToLogin(e) {
    e.preventDefault();

    alert('Registered Successfully! You can now log in.');
    window.location.href = "login.html";
}
