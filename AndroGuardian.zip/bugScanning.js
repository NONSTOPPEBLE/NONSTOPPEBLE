function performBugScan() {
    const file = document.getElementById('fileToScan').files[0];
    if (file) {
        const scanResult = Math.random() > 0.5 ? "Safe" : "Unsafe";

        const currentDate = new Date();
        const formattedDate = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(currentDate.getDate()).padStart(2, '0')}`;

        const scanData = {
            date: formattedDate,
            fileName: file.name,
            scanType: "Bug Scan",
            result: scanResult
        };

        // Fetch existing scan history
        let scanHistory = JSON.parse(localStorage.getItem('scanHistory') || "[]");
        scanHistory.push(scanData);
        localStorage.setItem('scanHistory', JSON.stringify(scanHistory));

        alert(`File ${file.name} has been scanned for bugs on ${formattedDate} and is ${scanResult}.`);
    } else {
        alert('Please select a file to scan.');
    }
}

function redirectToDashboard() {
    window.location.href = "dashboard.html";
}
