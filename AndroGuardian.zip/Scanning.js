let scanHistory = []; // Store scan history data

function performScan() {
    const file = document.getElementById('fileToScan').files[0];
    if (file) {
        const scanResult = Math.random() > 0.5 ? "Safe" : "Unsafe";

        const scanData = {
            date: new Date().toISOString().split('T')[0],
            fileName: file.name,
            scanType: "Malware Scan",
            result: scanResult
        };

        scanHistory.push(scanData);
        alert(`File ${file.name} has been scanned and is ${scanResult}.`);

        // Update local storage with the new scanHistory data (this ensures persistence)
        localStorage.setItem('scanHistory', JSON.stringify(scanHistory));
    } else {
        alert('Please select a file to scan.');
    }
}

// Load existing scan history from local storage (if available) when the page is loaded
document.addEventListener('DOMContentLoaded', function() {
    const savedHistory = localStorage.getItem('scanHistory');
    if (savedHistory) {
        scanHistory = JSON.parse(savedHistory);
    }
});
function redirectToDashboard() {
    window.location.href = "dashboard.html";
}
