function redirectToDashboard(e) {
    e.preventDefault();

    window.location.href = "dashboard.html";
}
