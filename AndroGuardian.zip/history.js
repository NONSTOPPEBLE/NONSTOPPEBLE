document.addEventListener('DOMContentLoaded', function() {
    // Fetch scan history data from local storage
    const scanHistoryData = JSON.parse(localStorage.getItem('scanHistory') || "[]");
    const tableBody = document.getElementById('scanHistoryTableBody');

    // Function to populate the table with scan history data
    scanHistoryData.forEach(entry => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${entry.date}</td>
            <td>${entry.fileName}</td>
            <td>${entry.scanType}</td>
            <td>${entry.result}</td>
        `;
        tableBody.appendChild(row);
    });
});
