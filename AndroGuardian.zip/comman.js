// Common JavaScript functions

function redirectToDashboard() {
    window.location.href = "dashboard.html";
}

// Function to save scan data to history
function saveToHistory(data) {
    let history = JSON.parse(localStorage.getItem('scanHistory') || "[]");
    history.push(data);
    localStorage.setItem('scanHistory', JSON.stringify(history));
}
